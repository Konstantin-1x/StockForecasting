package org.example.web.data;

import java.time.Instant;
import java.util.List;

public record ForecastDataQualityReport(
        Instant checkedAt,
        List<ForecastDataQualityCheck> checks
) {
    public boolean hasCriticalIssues() {
        return checks.stream().anyMatch(check -> "BAD".equals(check.status()));
    }
}

package org.example.web.data;

import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.StringJoiner;

@Controller
@RequestMapping("/admin/data")
public class DataTransferController {

    private final DataTransferService dataTransferService;

    public DataTransferController(DataTransferService dataTransferService) {
        this.dataTransferService = dataTransferService;
    }

    @GetMapping("/export")
    public ResponseEntity<StreamingResponseBody> exportData() {
        String fileName = dataTransferService.exportFileName();
        StreamingResponseBody body = dataTransferService::exportZip;
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment()
                        .filename(fileName, StandardCharsets.UTF_8)
                        .build()
                        .toString())
                .body(body);
    }

    @PostMapping("/import")
    public String importData(@RequestParam("file") MultipartFile file,
                             @RequestParam(name = "confirmReplace", defaultValue = "false") boolean confirmReplace,
                             RedirectAttributes redirectAttributes) {
        if (!confirmReplace) {
            redirectAttributes.addFlashAttribute("error", "Импорт не выполнен: нужно подтвердить замену локальной базы.");
            return "redirect:/admin";
        }
        if (file.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Импорт не выполнен: файл архива не выбран.");
            return "redirect:/admin";
        }

        try {
            DataImportResult result = dataTransferService.importZip(file.getInputStream());
            redirectAttributes.addFlashAttribute("status", "Импорт завершен: загружено "
                    + result.totalRows() + " строк из архива.");
        } catch (IOException | RuntimeException e) {
            redirectAttributes.addFlashAttribute("error", "Импорт не выполнен: " + errorMessage(e));
        }
        return "redirect:/admin";
    }

    private static String errorMessage(Exception error) {
        StringJoiner joiner = new StringJoiner(" -> ");
        Throwable current = error;
        while (current != null) {
            String message = current.getMessage();
            if (message != null && !message.isBlank()) {
                joiner.add(message);
            } else {
                joiner.add(current.getClass().getSimpleName());
            }
            current = current.getCause();
        }
        return joiner.toString();
    }
}

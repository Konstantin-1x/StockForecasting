package org.example.web.data;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UncheckedIOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Collections;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

@Service
public class DataTransferService {

    private static final List<TableSpec> TABLES = List.of(
            table("product_categories", "tables/product_categories.jsonl", "category_id", "category_id",
                    col("category_id", ColumnType.LONG),
                    col("category_name", ColumnType.STRING),
                    col("parent_category_id", ColumnType.LONG),
                    col("external_url", ColumnType.STRING),
                    col("wb_shard_key", ColumnType.STRING),
                    col("wb_query", ColumnType.STRING)),
            table("sellers", "tables/sellers.jsonl", "seller_id", "seller_id",
                    col("seller_id", ColumnType.LONG),
                    col("shop_name", ColumnType.STRING),
                    col("registration_date", ColumnType.LOCAL_DATE),
                    col("status", ColumnType.STRING)),
            table("products", "tables/products.jsonl", "product_id", "product_id",
                    col("product_id", ColumnType.LONG),
                    col("seller_id", ColumnType.LONG),
                    col("category_id", ColumnType.LONG),
                    col("marketplace_article", ColumnType.STRING),
                    col("product_name", ColumnType.STRING),
                    col("product_description", ColumnType.STRING),
                    col("base_price", ColumnType.DECIMAL),
                    col("current_stock", ColumnType.INTEGER)),
            table("promotions", "tables/promotions.jsonl", "promotion_id", "promotion_id",
                    col("promotion_id", ColumnType.LONG),
                    col("product_id", ColumnType.LONG),
                    col("planned_start_date", ColumnType.LOCAL_DATE),
                    col("planned_end_date", ColumnType.LOCAL_DATE),
                    col("actual_end_date", ColumnType.LOCAL_DATE),
                    col("bonus_amount", ColumnType.DECIMAL),
                    col("promo_product_quantity", ColumnType.INTEGER),
                    col("total_budget", ColumnType.DECIMAL),
                    col("status", ColumnType.STRING)),
            table("promotion_forecasts", "tables/promotion_forecasts.jsonl", "forecast_id", "forecast_id",
                    col("forecast_id", ColumnType.LONG),
                    col("product_id", ColumnType.LONG),
                    col("tracked_product_id", ColumnType.LONG),
                    col("calculated_at", ColumnType.INSTANT),
                    col("promotion_cost_forecast", ColumnType.DECIMAL),
                    col("promotion_purchase_forecast", ColumnType.INTEGER),
                    col("sellout_days_forecast", ColumnType.INTEGER),
                    col("promotion_start_hours_forecast", ColumnType.INTEGER),
                    col("promotion_stock_forecast", ColumnType.INTEGER),
                    col("confidence_interval", ColumnType.DECIMAL),
                    col("forecast_model", ColumnType.STRING),
                    col("training_sample_count", ColumnType.INTEGER),
                    col("validation_mae", ColumnType.DECIMAL)),
            table("competitor_offers", "tables/competitor_offers.jsonl", "competitor_offer_id", "competitor_offer_id",
                    col("competitor_offer_id", ColumnType.LONG),
                    col("category_id", ColumnType.LONG),
                    col("competitor_name", ColumnType.STRING),
                    col("product_name", ColumnType.STRING),
                    col("competitor_price", ColumnType.DECIMAL),
                    col("competitor_discount", ColumnType.DECIMAL),
                    col("feedback_reward", ColumnType.DECIMAL),
                    col("benefit_percent", ColumnType.DECIMAL),
                    col("stock_quantity", ColumnType.INTEGER),
                    col("marketplace_article", ColumnType.STRING),
                    col("card_url", ColumnType.STRING),
                    col("collected_at", ColumnType.INSTANT)),
            table("tracked_marketplace_products", "tables/tracked_marketplace_products.jsonl", "tracked_product_id", "tracked_product_id",
                    col("tracked_product_id", ColumnType.LONG),
                    col("category_id", ColumnType.LONG),
                    col("marketplace_article", ColumnType.STRING),
                    col("product_name", ColumnType.STRING),
                    col("seller_name", ColumnType.STRING),
                    col("supplier_id", ColumnType.LONG),
                    col("discovered_price", ColumnType.DECIMAL),
                    col("feedback_reward", ColumnType.DECIMAL),
                    col("benefit_percent", ColumnType.DECIMAL),
                    col("discovered_stock", ColumnType.INTEGER),
                    col("card_url", ColumnType.STRING),
                    col("detail_url", ColumnType.STRING),
                    col("discovered_at", ColumnType.INSTANT),
                    col("active", ColumnType.BOOLEAN),
                    col("completed_at", ColumnType.INSTANT)),
            table("marketplace_monitoring_jobs", "tables/marketplace_monitoring_jobs.jsonl", "monitoring_job_id", "monitoring_job_id",
                    col("monitoring_job_id", ColumnType.LONG),
                    col("tracked_product_id", ColumnType.LONG),
                    col("stage", ColumnType.INTEGER),
                    col("next_run_at", ColumnType.INSTANT),
                    col("finished", ColumnType.BOOLEAN),
                    col("last_run_at", ColumnType.INSTANT),
                    col("last_error", ColumnType.STRING),
                    col("created_at", ColumnType.INSTANT),
                    col("updated_at", ColumnType.INSTANT)),
            table("marketplace_product_snapshots", "tables/marketplace_product_snapshots.jsonl", "snapshot_id", "snapshot_id",
                    col("snapshot_id", ColumnType.LONG),
                    col("tracked_product_id", ColumnType.LONG),
                    col("collected_at", ColumnType.INSTANT),
                    col("price", ColumnType.DECIMAL),
                    col("stock_quantity", ColumnType.INTEGER),
                    col("feedback_reward", ColumnType.DECIMAL),
                    col("benefit_percent", ColumnType.DECIMAL),
                    col("rating", ColumnType.DECIMAL),
                    col("reviews_count", ColumnType.INTEGER),
                    col("measurement_source", ColumnType.STRING),
                    col("raw_json", ColumnType.STRING))
    );

    private final JdbcTemplate jdbcTemplate;
    private final ObjectMapper objectMapper;
    private final DataTransferState transferState;
    private final TransactionTemplate exportTransactionTemplate;
    private final TransactionTemplate importTransactionTemplate;

    public DataTransferService(JdbcTemplate jdbcTemplate,
                               ObjectMapper objectMapper,
                               DataTransferState transferState,
                               PlatformTransactionManager transactionManager) {
        this.jdbcTemplate = jdbcTemplate;
        this.objectMapper = objectMapper;
        this.transferState = transferState;
        this.exportTransactionTemplate = new TransactionTemplate(transactionManager);
        this.exportTransactionTemplate.setReadOnly(true);
        this.exportTransactionTemplate.setIsolationLevel(TransactionDefinition.ISOLATION_REPEATABLE_READ);
        this.exportTransactionTemplate.setTimeout(3600);
        this.importTransactionTemplate = new TransactionTemplate(transactionManager);
        this.importTransactionTemplate.setTimeout(3600);
    }

    public String exportFileName() {
        String timestamp = java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")
                .withZone(ZoneId.systemDefault())
                .format(Instant.now());
        return "stockforecasting-export-" + timestamp + ".zip";
    }

    public void exportZip(OutputStream outputStream) throws IOException {
        try (DataTransferState.TransferLock ignored = transferState.begin("export")) {
            exportTransactionTemplate.executeWithoutResult(status -> {
                try (ZipOutputStream zip = new ZipOutputStream(outputStream, StandardCharsets.UTF_8)) {
                    writeManifest(zip);
                    for (TableSpec table : TABLES) {
                        writeTable(zip, table);
                    }
                } catch (IOException e) {
                    throw new UncheckedIOException(e);
                }
            });
        } catch (UncheckedIOException e) {
            throw e.getCause();
        }
    }

    public DataImportResult importZip(InputStream inputStream) throws IOException {
        Path tempFile = Files.createTempFile("stockforecasting-import-", ".zip");
        try (DataTransferState.TransferLock ignored = transferState.begin("import")) {
            Files.copy(inputStream, tempFile, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            return importTransactionTemplate.execute(status -> {
                try {
                    return importZipFile(tempFile);
                } catch (IOException e) {
                    throw new UncheckedIOException(e);
                }
            });
        } catch (UncheckedIOException e) {
            throw e.getCause();
        } finally {
            Files.deleteIfExists(tempFile);
        }
    }

    private void writeManifest(ZipOutputStream zip) throws IOException {
        Map<String, Object> manifest = new LinkedHashMap<>();
        manifest.put("format", "stockforecasting-jsonl-zip");
        manifest.put("version", 1);
        manifest.put("exportedAt", Instant.now().toString());

        List<Map<String, Object>> tables = new ArrayList<>();
        for (TableSpec table : TABLES) {
            Map<String, Object> tableInfo = new LinkedHashMap<>();
            tableInfo.put("name", table.tableName());
            tableInfo.put("entry", table.entryName());
            tableInfo.put("rows", countRows(table.tableName()));
            tables.add(tableInfo);
        }
        manifest.put("tables", tables);

        zip.putNextEntry(new ZipEntry("manifest.json"));
        zip.write(objectMapper.writerWithDefaultPrettyPrinter()
                .writeValueAsString(manifest)
                .getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    private void writeTable(ZipOutputStream zip, TableSpec table) throws IOException {
        zip.putNextEntry(new ZipEntry(table.entryName()));
        String sql = "select " + table.columnNamesCsv() + " from " + table.tableName() + " order by " + table.orderBy();
        jdbcTemplate.query(sql, resultSet -> {
            try {
                Map<String, Object> row = new LinkedHashMap<>();
                for (ColumnSpec column : table.columns()) {
                    row.put(column.name(), normalizeValue(resultSet.getObject(column.name())));
                }
                zip.write(objectMapper.writeValueAsString(row).getBytes(StandardCharsets.UTF_8));
                zip.write('\n');
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
        });
        zip.closeEntry();
    }

    private DataImportResult importZipFile(Path zipPath) throws IOException {
        Map<String, Long> importedRows = new LinkedHashMap<>();
        truncateTables();
        try (ZipFile zip = new ZipFile(zipPath.toFile(), StandardCharsets.UTF_8)) {
            validateManifest(zip);
            for (TableSpec table : TABLES) {
                long rows = "product_categories".equals(table.tableName())
                        ? importProductCategories(zip, table)
                        : importTable(zip, table);
                importedRows.put(table.tableName(), rows);
            }
        }
        resetSequences();
        long totalRows = importedRows.values().stream().mapToLong(Long::longValue).sum();
        return new DataImportResult(totalRows, importedRows);
    }

    private void validateManifest(ZipFile zip) throws IOException {
        ZipEntry manifestEntry = zip.getEntry("manifest.json");
        if (manifestEntry == null) {
            throw new IOException("Архив не содержит manifest.json");
        }
        try (InputStream input = zip.getInputStream(manifestEntry)) {
            JsonNode manifest = objectMapper.readTree(input);
            if (!"stockforecasting-jsonl-zip".equals(manifest.path("format").asText())) {
                throw new IOException("Неверный формат архива экспорта");
            }
        }
    }

    private long importProductCategories(ZipFile zip, TableSpec table) throws IOException {
        List<CategoryParentRef> parentRefs = new ArrayList<>();
        long rows = importRows(zip, table, row -> {
            Long id = nullableLong(row.get("category_id"));
            Long parentId = nullableLong(row.get("parent_category_id"));
            if (id != null && parentId != null) {
                parentRefs.add(new CategoryParentRef(id, parentId));
            }
            insertRow(table, row, Collections.singletonMap("parent_category_id", null));
        });

        for (CategoryParentRef parentRef : parentRefs) {
            jdbcTemplate.update("""
                    update product_categories
                    set parent_category_id = ?
                    where category_id = ?
                    """, parentRef.parentCategoryId(), parentRef.categoryId());
        }
        return rows;
    }

    private long importTable(ZipFile zip, TableSpec table) throws IOException {
        return importRows(zip, table, row -> insertRow(table, row, Map.of()));
    }

    private long importRows(ZipFile zip, TableSpec table, RowImporter rowImporter) throws IOException {
        ZipEntry entry = zip.getEntry(table.entryName());
        if (entry == null) {
            throw new IOException("Архив не содержит таблицу " + table.entryName());
        }

        long rows = 0;
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(zip.getInputStream(entry), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.isBlank()) {
                    continue;
                }
                JsonNode row = objectMapper.readTree(line);
                rowImporter.importRow(row);
                rows++;
            }
        }
        return rows;
    }

    private void insertRow(TableSpec table, JsonNode row, Map<String, Object> overrides) {
        String sql = "insert into " + table.tableName()
                + " (" + table.columnNamesCsv() + ") values ("
                + "?,".repeat(table.columns().size()).replaceAll(",$", "")
                + ")";
        jdbcTemplate.update(connection -> {
            PreparedStatement statement = connection.prepareStatement(sql);
            for (int index = 0; index < table.columns().size(); index++) {
                ColumnSpec column = table.columns().get(index);
                Object value = overrides.containsKey(column.name())
                        ? overrides.get(column.name())
                        : importValue(column, row.get(column.name()));
                statement.setObject(index + 1, value);
            }
            return statement;
        });
    }

    private void truncateTables() {
        String tableNames = String.join(", ", TABLES.stream().map(TableSpec::tableName).toList());
        jdbcTemplate.execute("truncate table " + tableNames + " restart identity cascade");
    }

    private void resetSequences() {
        for (TableSpec table : TABLES) {
            jdbcTemplate.execute("""
                    select setval(
                        pg_get_serial_sequence('%s', '%s'),
                        greatest(coalesce((select max(%s) from %s), 0), 1),
                        coalesce((select max(%s) from %s), 0) > 0
                    )
                    """.formatted(
                    table.tableName(),
                    table.idColumn(),
                    table.idColumn(),
                    table.tableName(),
                    table.idColumn(),
                    table.tableName()
            ));
        }
    }

    private long countRows(String tableName) {
        Long count = jdbcTemplate.queryForObject("select count(*) from " + tableName, Long.class);
        return count == null ? 0 : count;
    }

    private Object normalizeValue(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Timestamp timestamp) {
            return timestamp.toInstant().toString();
        }
        if (value instanceof OffsetDateTime offsetDateTime) {
            return offsetDateTime.toInstant().toString();
        }
        if (value instanceof Instant instant) {
            return instant.toString();
        }
        if (value instanceof LocalDateTime localDateTime) {
            return localDateTime.atZone(ZoneId.systemDefault()).toInstant().toString();
        }
        if (value instanceof Date date) {
            return date.toLocalDate().toString();
        }
        if (value instanceof LocalDate localDate) {
            return localDate.toString();
        }
        return value;
    }

    private Object importValue(ColumnSpec column, JsonNode value) {
        if (value == null || value.isNull()) {
            return null;
        }
        return switch (column.type()) {
            case LONG -> value.longValue();
            case INTEGER -> value.intValue();
            case STRING -> value.asText();
            case DECIMAL -> decimalValue(value);
            case INSTANT -> Timestamp.from(Instant.parse(value.asText()));
            case LOCAL_DATE -> Date.valueOf(LocalDate.parse(value.asText()));
            case BOOLEAN -> value.booleanValue();
        };
    }

    private BigDecimal decimalValue(JsonNode value) {
        if (value.isNumber()) {
            return value.decimalValue();
        }
        return new BigDecimal(value.asText());
    }

    private Long nullableLong(JsonNode value) {
        return value == null || value.isNull() ? null : value.longValue();
    }

    private static TableSpec table(String tableName,
                                   String entryName,
                                   String idColumn,
                                   String orderBy,
                                   ColumnSpec... columns) {
        return new TableSpec(tableName, entryName, idColumn, orderBy, List.of(columns));
    }

    private static ColumnSpec col(String name, ColumnType type) {
        return new ColumnSpec(name, type);
    }

    private enum ColumnType {
        LONG,
        INTEGER,
        STRING,
        DECIMAL,
        INSTANT,
        LOCAL_DATE,
        BOOLEAN
    }

    private record ColumnSpec(String name, ColumnType type) {
    }

    private record TableSpec(
            String tableName,
            String entryName,
            String idColumn,
            String orderBy,
            List<ColumnSpec> columns
    ) {
        String columnNamesCsv() {
            return String.join(", ", columns.stream().map(ColumnSpec::name).toList());
        }
    }

    private record CategoryParentRef(Long categoryId, Long parentCategoryId) {
    }

    @FunctionalInterface
    private interface RowImporter {
        void importRow(JsonNode row) throws IOException;
    }
}
